﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace MainProject
{
    class Jobs
    {
        public string Companyname { get; set; }
        public string jobrole { get; set; }
        public string experience { get; set; }
    }
    internal class Program
    {
        /*--------------Admin Login----------------*/
        static void AdminLogin()
        {
            Console.WriteLine("                                                               ............................................................................................");

            Console.Write("                                                                                                     Enter User-ID  : ");
            string uid = Console.ReadLine();
            Console.WriteLine();
            Console.Write("                                                                                                     Enter Password : ");

            string pid = Console.ReadLine();
            Console.WriteLine("                                                               .............................................................................................");

            Console.WriteLine();
            if (uid == "admin" && pid == "passcode")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("                                                           ......................................Logged In Successfully.................................");
                Console.WriteLine();
                while (true)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("                                                                                    Post Jobs   ||   Delete Jobs   ||  View Jobs    ||  Logout       ");
                    string search = Console.ReadLine();
                    switch (search)
                    {
                        case "Post Jobs":
                            PostJobs();
                            break;
                        case "Delete Jobs":
                            DeleteJobs();
                            break;
                        case "View Jobs":
                            ViewJobs();
                            break;
                        case "Logout":
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                                                        ...............................Admin LOGGED OUT!!!!.................");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.WriteLine();
                            defaultcase();
                            break;
                        default:
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                                                                                       Invalid Choice Entered");
                            break;
                    }
                }
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                                                                                                   Invalid LogIn Credentials ");
                Console.WriteLine("                                                                                                           Try Again ");
                Console.ForegroundColor= ConsoleColor.White;
                Console.WriteLine();
                AdminLogin();
            }
        }
        static List<Jobs> jobs= new List<Jobs>();
        static List<Jobs> intern= new List<Jobs>();
        /*-----------------AddJobs------------------------*/
        static void PostJobs()
        {
            Console.WriteLine("               What do you want to post ?(Jobs or Internships)");
            string str = Console.ReadLine();
            Console.WriteLine();
            switch (str)
            {
                case "Jobs":
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("                   ..........................POST JOBS HERE.........................");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine();
                    Console.WriteLine("Enter How many Jobs you want to Post");
                    int j = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                    for (int i = 0; i < j; i++)
                    {
                        Update:
                        Console.Write("       Company Name        :");
                        string cname1 = Console.ReadLine();
                        Console.Write("       Role                :");
                        string jrole1 = Console.ReadLine();
                        Console.Write("       Experience          :");
                        string exp1 = Console.ReadLine();
                        Console.Write("       Location            :");
                        String loc1 = Console.ReadLine();
                        Console.Write("                     Do you want to make changes or not  (yes/no)?");
                        string y= Console.ReadLine();
                        if(y=="yes")
                        {
                            goto Update;
                        }
                        Console.WriteLine("                   ((Enter Post To post job)) ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        string pos = Console.ReadLine();
                        Console.WriteLine();
                        if (pos == "Post")
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("            ---------------------JOB POSTED SUCCESSFULLY-------------------");
                            Console.ForegroundColor = ConsoleColor.White;
                            Jobs job = new Jobs
                            {
                                Companyname = cname1,
                                jobrole = jrole1,
                                experience = exp1

                            };
                            jobs.Add(job);

                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                       Job doesn't posted !!! Please check once again !!");
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                    }
                    break;

                case "Internships":
                    Console.ForegroundColor= ConsoleColor.Green;
                    Console.WriteLine("                 ................POST INTERNSHIPS HERE............................");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("Enter How many Jobs you want to Post");
                    int j1 = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();
                    for (int i = 0; i < j1; i++)
                    {
                        Console.Write("       Company Name        :");
                        string cname2 = Console.ReadLine();
                        Console.Write("       Role                :");
                        string jrole2 = Console.ReadLine();
                        Console.Write("       Experience          :");
                        string exp2 = Console.ReadLine();
                        Console.Write("       Location            :");
                        String loc2 = Console.ReadLine();
                        Console.WriteLine("                    Enter Post To post intrsnship ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        string pos = Console.ReadLine();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine();
                        if (pos == "Post")
                        {
                            Console.ForegroundColor=ConsoleColor.Green;
                            Console.WriteLine("         -----------------INTERNSHIP POSTED SUCCESSFULLY----------");
                            Jobs name= new Jobs
                            {
                                Companyname = cname2,
                                jobrole = jrole2,
                                experience = exp2

                            };
                            intern.Add(name);
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("         Internship doesn't posted !!! Please check once again !!");
                            Console.ForegroundColor= ConsoleColor.White;
                        }
                    }
                    break;
            }
        }
       /*-----------------View Jobs---------------------*/
       static void ViewJobs()
        {
            if (jobs != null && jobs.Any())
            {
                Console.ForegroundColor = ConsoleColor.DarkMagenta;
                Console.WriteLine("List of Jobs:");
                Console.WriteLine();
                int i = 1;
                foreach (var job in jobs)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("Option :" + i);
                    i++;
                    Console.WriteLine(    $"Company   : {job.Companyname} \n " +
                                          $"Role      : {job.jobrole} \n " +
                                          $"Experience: {job.experience}");
                    Console.WriteLine();
                }

            }
            else
            {

                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("               JOBS NOT FOUND!!!.......");
                Console.ForegroundColor = ConsoleColor.White;
            }
               
        }
        /*-----------------View Interns-----------------*/
        static void ViewIntern()
        {
            if (intern == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("              INTERNSHIP'S NOT FOUND!!!!.....");
                Console.ForegroundColor = ConsoleColor.White;
            }
            else
            {
                Console.ForegroundColor=ConsoleColor.DarkMagenta;
                Console.WriteLine("              List of Internships:");
                Console.WriteLine();
                int i = 1;
                foreach (var job in intern)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine(i);
                    i++;
                    Console.WriteLine($"Company:{job.Companyname} \n " +
                                      $"Role: {job.jobrole} \n " +
                                      $"Experience: {job.experience}");
                    Console.WriteLine();
                }
            }
        }
        /*-----------------Delete Jobs-------------------*/
        static void DeleteJobs()
        {
            Console.WriteLine("Let me know You want to delete Jobs or Internships!!");
            string str1= Console.ReadLine();
            Console.WriteLine();
            switch (str1)
            {
                case "Jobs":
                    ViewJobs();
                    Console.ForegroundColor= ConsoleColor.Green;
                    Console.WriteLine("                        YOU CAN DELETE JOBS HERE   ");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine();
                    Console.Write("Enter Company Name  :");
                    string comname= Console.ReadLine();
                    Console.Write("Enter Job Role      :");
                    string jrole= Console.ReadLine();
                    Console.WriteLine();
                    int index=jobs.FindIndex(job=>(job.Companyname.Equals(comname, StringComparison.OrdinalIgnoreCase)&& job.jobrole.Equals(jrole,StringComparison.OrdinalIgnoreCase)));
                    if(index != -1)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        jobs.RemoveAt(index);
                        Console.WriteLine("                       Job Deleted Successfully");
                        Console.ForegroundColor=ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                       Job Not Found!!!!!!!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "Internships":
                    ViewIntern();
                    Console.ForegroundColor= ConsoleColor.Green;
                    Console.WriteLine("                           YOU CAN DELETE INTERNSHIPS HERE");
                    Console.Write("Enter Company Name");
                    string coname = Console.ReadLine();
                    Console.Write("Enter Job Role");
                    string irole = Console.ReadLine();
                    Console.WriteLine();
                    int inh = jobs.FindIndex(job => (job.Companyname.Equals(coname, StringComparison.OrdinalIgnoreCase) && job.jobrole.Equals(irole, StringComparison.OrdinalIgnoreCase)));
                    if (inh != -1)
                    {
                        jobs.RemoveAt(inh);
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("                       Job Deleted Successfully");
                        Console.ForegroundColor= ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                       Job Not Found!!!!!!!");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
            }
        }
        /*----------------------------------------UserLogin---------------------------------*/
        static void UserLogin()
        {
            Console.WriteLine("                         NOTE: If this is the first time please choose the option (Register)");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine();
            Console.WriteLine("                                           -----------REGISTER-----------------");
            Console.ForegroundColor = ConsoleColor.White;
            Register();

            Console.WriteLine();
            Console.ForegroundColor=ConsoleColor.Yellow;
            Console.WriteLine("           Profile Creation   ||     Technical Details     ||        Job Search      ||         Contact Us      ||     Logout");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;

            while (true)
            {
                //System.Threading.Thread.Sleep(1000);

                Console.WriteLine("Choose any option from the above");


                String ch = (Console.ReadLine());
                switch (ch)
                {


                    case "Profile Creation":
                        ProfileCreation();
                        break;
                    case "Technical Details":
                        TechnicalDetails();
                        break;

                    case "Job Search":
                        JobSearch();
                        break;
                    case "Contact Us":
                        Contactus();
                        break;
                    case "Logout":
                        defaultcase();
                        break;


                    default:
                        Console.ForegroundColor = ConsoleColor.DarkBlue;
                        Console.WriteLine("please enter valid choice");
                        Console.ForegroundColor = ConsoleColor.White;
                        break;
                }


            }
        }
        /*-------------------Login for user-------------------*/
        static void Login(string u, string p)
        {
        a:
            Console.WriteLine("Here's your Login process : ");
            Console.WriteLine("                 -----------------------------------------------------------------------------");
            Console.Write("                                               Enter User-ID  :");
            String uid = (Console.ReadLine());
            Console.WriteLine();

            Console.Write("                                               Enter password :");
            String pwd = (Console.ReadLine());
            Console.WriteLine("                 ------------------------------------------------------------------------------");
            System.Threading.Thread.Sleep(1000);
            if (p == pwd && u == uid)
            {
                Console.ForegroundColor= ConsoleColor.Yellow;
                Console.WriteLine();
                Console.WriteLine("                                                   ---Welcome To SVEC JOB PORTAL!---");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("                                                        Login Successful!!!");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Invalid Login Please enter correct creditials.");
                Console.ForegroundColor = ConsoleColor.White;
                goto a;
            }


        }

        /*------------------------Register----------------------*/
        static void Register()
        {
            Console.WriteLine("Here's your registration process");
        usernamesetting:
            Console.Write("UserName                 :");
            string fname = Console.ReadLine();
            if (fname.Length < 5)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Your username doesn't reach minimum number of characters");
                Console.ForegroundColor = ConsoleColor.White;
                goto usernamesetting;
            }
            Console.Write("Mobile Number            :");
            String num = Console.ReadLine();
            Console.Write("Email-id                 :");
            String e = Console.ReadLine();
            Console.Write("Set Password             :");

        passwordsetting:
            String pwd1 = Console.ReadLine();
            if (pwd1.Length < 4)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Your password doesn't reach minimum number of characters");
                Console.ForegroundColor = ConsoleColor.White;
                goto passwordsetting;
            }

            Console.Write("Confirm Passwrod         :");
        confirmation:

            String pwd2 = (Console.ReadLine());
            if (pwd1 != pwd2)
            {
                Console.ForegroundColor= ConsoleColor.Red;
                Console.WriteLine("                                                            ---please enter the correct password---");
                Console.ForegroundColor = ConsoleColor.White;
                goto confirmation;
            }
            else
            {
                Console.WriteLine("                                        .....................your Rergistration Successful!!..............");
                Console.ForegroundColor = ConsoleColor.White;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("                                                    you can use these credentials for login again!");
                Console.ForegroundColor = ConsoleColor.White; ;
            }
            //Console.ForegroundColor=ConsoleColor.Green;
           
            Login(fname, pwd2);
        }

        static void InvalidLog()
        {
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.WriteLine("Register Before LogIn");
            Console.ForegroundColor = ConsoleColor.White;
        }

        /*---------------------------Profile Creation----------------------------*/
        static void ProfileCreation()
        {
            Console.WriteLine("      Complete your profile");
            Console.WriteLine("      (Don't miss any chance to impress recruiters !)");

            Console.WriteLine("1.Basic Details");
            Console.Write("Name          :");
            String name = Console.ReadLine();
            Console.Write("Gender        :");
            String gen = Console.ReadLine();
            Console.Write("Address       :");
            String add = Console.ReadLine();
            Console.Write("Date Of Birth :");
            String dob = Console.ReadLine();
            Console.Write("EMail-Id      :");
            String eml = Console.ReadLine();
            Console.Write("Mobile Number :");
            String phn = Console.ReadLine();





            Console.WriteLine("2.Your Career Preferenfes");
            Console.WriteLine(" Looking for 1.Internship  2.Job  3.Contractual");
            Console.WriteLine("select your preferred choice");
            String ch1 = Console.ReadLine();




            if (ch1 == "Internship" || ch1 == "Job" || ch1 == "Contractual")
            {
                Console.WriteLine(" your preferences is added");
            }
            else if (ch1 == "Job,Contractual" || ch1 == "Internship,Contractual" || ch1 == "Internship,Job")
            {
                Console.WriteLine(" your preferences are added");
            }
            else
            {
                Console.WriteLine(" Enter Valid choice Please !!!");


            }

            Console.WriteLine();
            Console.WriteLine("                       Your Career Preferences are addded");
            Console.WriteLine();

            Console.WriteLine("Availability to work :");
            String days = Console.ReadLine();
            Console.WriteLine("Preferred Location : (3 locations must be needed)");
            String lo1 = Console.ReadLine();
            String lo2 = Console.ReadLine();
            String lo3 = Console.ReadLine();


            Console.WriteLine("3.Education");
            Console.WriteLine("1. B.Tech/BE");
            Console.Write("College Name :");
            String clg1 = Console.ReadLine();
            Console.Write("Grade        :");
            String grade1 = Console.ReadLine();
            Console.Write("Location     :");
            String loc1 = Console.ReadLine();
            Console.WriteLine("2. Intermmediate/Diploma");
            Console.Write("College Name : ");
            String clg2 = Console.ReadLine();
            Console.Write("Grade        : ");
            String grade2 = Console.ReadLine();
            Console.Write("Location     : ");
            String loc2 = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("3. School");
            Console.Write("School Name  : ");
            String clg3 = Console.ReadLine();
            Console.Write("Grade        : ");
            String grade3 = Console.ReadLine();
            Console.Write("Location     : ");
            String loc3 = Console.ReadLine();

            Console.WriteLine("No.of Languages Known");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Give " + n2 + " languages that you know: ");

            String[] arr2 = new String[n2];
            for (int i = 0; i < n2; i++)
            {
                arr2[i] = Console.ReadLine();
            }



            Console.WriteLine();
            Console.WriteLine("                 Your Basic Details");
            Console.WriteLine();
            Console.WriteLine("         Name             : " + name);
            Console.WriteLine("         Gender           : " + gen);
            Console.WriteLine("         Address          : " + add);
            Console.WriteLine("         Date of Birth    : " + dob);
            Console.WriteLine("         Email Id         : " + eml);
            Console.WriteLine("         Mobile No.       : " + phn);
            Console.WriteLine();

            Console.WriteLine("                 Locations that you have chosen :");
            Console.WriteLine();
            Console.WriteLine("         first  location  : " + lo1);
            Console.WriteLine("         Second location  : " + lo2);
            Console.WriteLine("         Third  location  : " + lo3);

            Console.WriteLine();
            Console.WriteLine("                 Your Education Details");
            Console.WriteLine();

            Console.Write("                  B.Tech/BE ");
            Console.WriteLine();
            Console.WriteLine("          College Name    : " + clg1);
            Console.WriteLine("          Grade(in CGPA)  : " + grade1);
            Console.WriteLine("          Address         : " + loc1);
            Console.WriteLine();
            Console.Write("                  Inter/Diploma ");
            Console.WriteLine();
            Console.WriteLine("          College Name    : " + clg2);
            Console.WriteLine("          Grade(in CGPA)  : " + grade2);
            Console.WriteLine("          Address         : " + loc2);
            Console.WriteLine();
            Console.Write("                  Secondary Education ");
            Console.WriteLine();
            Console.WriteLine("          School Name     : " + clg3);
            Console.WriteLine("          Grade(in CGPA)  : " + grade3);
            Console.WriteLine("          Address         : " + loc3);
            Console.WriteLine();
            Console.WriteLine("               Languages that you have given");

            foreach (String i in arr2)
            {
                Console.WriteLine("       " + i);
            }
            Console.WriteLine("Enter 'OK' To submit the details");
            String ok = Console.ReadLine();
            Console.WriteLine("Your Profile is Creatd successfully !");
        }

        /*--------------------------------TechnicalDetails-----------------------*/
        static void TechnicalDetails()
        {
            Console.WriteLine();
            Console.WriteLine("Give your Technical Details here");
            Console.WriteLine("1.Keyskills\n2.Internships\n3.Projects\n4.Competitive Exams\n5.Employment\n6.Awards\n7.Academic Achievements\n8.submit\n");
            Console.WriteLine("(NOTE : Enter OK at last to Complete the profile)");
            Console.WriteLine("Go through the above options using their numbers");
            while (true)
            {
                String ch2 = Console.ReadLine();

                switch (ch2)
                {
                    case "1":
                        Console.WriteLine("Total skills you have: ");
                        int n1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Please enter " + n1 + " skills you have");

                        String[] arr1 = new String[n1];
                        for (int i = 0; i < arr1.Length; i++)
                        {
                            arr1[i] = Console.ReadLine();
                        }
                        Console.WriteLine("Skiils that you have given :");
                        foreach (String i in arr1)
                        {
                            Console.WriteLine("    " + i);
                        }
                        Console.WriteLine();


                        break;
                    case "2":
                        Console.WriteLine("Talk about your Internships here");
                        String intern = Console.ReadLine();
                        break;
                    case "3":
                        Console.WriteLine("Talk about your projects");
                        String projects = Console.ReadLine();
                        break;
                    case "4":
                        Console.WriteLine("Talk about your competitive exams");
                        String cexam = Console.ReadLine();
                        break;
                    case "5":
                        Console.WriteLine("Talk about your employment");
                        String emp = Console.ReadLine();
                        break;
                    case "6":
                        Console.WriteLine("Talk about your awards");
                        String awd = Console.ReadLine();
                        break;
                    case "7":
                        Console.WriteLine("Talk about your Academic Achievements");
                        String ach = Console.ReadLine();
                        break;
                    case "8":
                        Console.WriteLine("All your technical details are submitted .");
                        Console.WriteLine("Thank you !!");

                        // Console.ReadLine();
                        break;
                    default:

                        break;




                }
                break;
            }
        }

        /*------------------------------Job Search------------------------------*/
        static void JobSearch()
        {
            Console.WriteLine("                        You looking for ?");
            Console.WriteLine();
            Console.WriteLine("                     a. Jobs     b. Internships");
            Console.WriteLine("select one from above (a or b)");
            string choice = Console.ReadLine();
            if (choice.ToLower() == "a")
            {
                Console.WriteLine("Course");
                String course = Console.ReadLine();
                Console.WriteLine("Location");
                String loc5 = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("                  Based on the above details");
                ViewJobs();
                if(jobs.Count==0)
                {
                    Console.ForegroundColor= ConsoleColor.Red;
                    Console.WriteLine("              No Jobs Available....");
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Companies();
                }
            }
            if (choice.ToLower() == "b")
            {
                Console.WriteLine("Course");
                String course = Console.ReadLine();
                Console.WriteLine("Location");
                String loc5 = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("                  Based on the above details");
                ViewIntern();
                if (intern.Count == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("              No Internships Available....");
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Companies();
                }
            }
            
        }
        /*-----------------------------------Companies---------------------------------*/
        static void Companies()
        {
            Console.WriteLine();
            Console.Write("                        Select An Option From the above : ");
            string s= Console.ReadLine();
            switch (s)
            {
                case "1":
                    
                    Console.WriteLine("                  TYPE APPLY TO SUBMIT YOUR APPLICATION  ");
                    string app1= Console.ReadLine();
                    if(app1.ToLower()=="apply")
                    {
                        Console.ForegroundColor=ConsoleColor.Green;
                        Console.WriteLine("............Job Applied successfully...............");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor=ConsoleColor.Red;
                        Console.WriteLine("               Your APPLICATION was NOT SUBMITTED");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "2":
                   
                    Console.WriteLine("                   TYPE APPLY TO SUBMIT YOUR APPLICATION  ");
                    string app2 = Console.ReadLine();
                    if (app2.ToLower() == "apply")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("...............Your Application submitted successfully...............");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("               Your APPLICATION was NOT SUBMITTED");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "3":
                    
                    Console.WriteLine("                  TYPE APPLY TO SUBMIT YOUR APPLICATION  ");
                    string app3 = Console.ReadLine();
                    if (app3.ToLower() == "apply")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("..............Job applied successfully...............");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("             Your APPLICATION was NOT SUBMITTED");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "4":
                    Console.WriteLine("                 TYPE APPLY TO SUBMIT YOUR APPLICATION  ");
                    string app4= Console.ReadLine();
                    if (app4.ToLower() == "apply")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(".............Job applied successfully...............");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("             Your APPLICATION was NOT SUBMITTED");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                case "5":
                   
                    Console.WriteLine("                 TYPE APPLY TO SUBMIT YOUR APPLICATION  ");
                    string app5 = Console.ReadLine();
                    if (app5.ToLower() == "apply")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(".............Job applied successfully...............");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("             Your APPLICATION was NOT SUBMITTED");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    break;
                default:
                    Console.WriteLine("Choose valid option");
                    break;
            }
        }
        
        /*-----------------------------------  Contact Us  -----------------------------------*/
        static void Contactus()
        {
            Console.WriteLine();
            Console.WriteLine("Connect with us...");
            Console.WriteLine("we would love to respond to your queries and help you succeed");
            Console.WriteLine("Feel free to get in touch with us");
            Console.WriteLine();

            Console.WriteLine("!!Reach us!!");
            Console.WriteLine("E-mail   :  SVEC@gmail.com");
            Console.WriteLine("Phone    :  7093024228");
            Console.WriteLine("Address  :  Peddatadepalli");
            Console.WriteLine("            Tadepalligudem,WestGodavari Dist.");
            Console.WriteLine("            PINCODE : 534141");
            Console.WriteLine();
            Console.WriteLine("SEND MESSAGE");
            Console.Write("Name          : ");

            String nam = Console.ReadLine();
            Console.Write("Mobile Number : ");

            String phn = Console.ReadLine();
            Console.Write("Email-id      : ");

            String Email = Console.ReadLine();
            Console.Write("Message       : ");

            String sub = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("Thankyou for sending us message !!");
            Console.WriteLine("Your query is resolved soon !");
        }

        /*---------------------------Main Page-----------------------------*/
        static void Main(string[] args)
        {

            Console.WriteLine("                                                                                                   Welcome to SVEC JOB PORTAL ");
            Console.WriteLine();
            defaultcase();
        }
        /*------------------DefaultCase-------------*/
        static void defaultcase()
        {
            Console.WriteLine();
            Console.WriteLine("                                                                              AdminLogin      ||           UserLogin          ||         Exit ");
            string ind = Console.ReadLine();
            switch (ind)
            {
                case "AdminLogin":
                    AdminLogin();
                    break;
                case "UserLogin":
                    UserLogin();
                    break;
                case "Exit":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Choose Valid Option....");
                    defaultcase();
                    break;
            }
        }
    }
}